#pragma once
#include <stdbool.h>

extern bool config_print_instr;
extern bool config_print_reg;
extern bool config_print_mem_access;
extern bool config_print_platform;
